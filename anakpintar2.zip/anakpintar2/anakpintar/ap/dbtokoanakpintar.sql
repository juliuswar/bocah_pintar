drop database if exists dbtokoanakpintar;
create database dbtokoanakpintar;
use dbtokoanakpintar;

create table tblAdmin (
	id_admin int(11)PRIMARY KEY AUTO_INCREMENT,
	username varchar(50),
	password varchar(30)
);

insert into tblAdmin(`id_admin`,`username`,`password`) values 
(113,'budi','budiandrea');

create table tblBarang (
	id_barang varchar(10)PRIMARY KEY,
	nama_barang varchar(20),
	harga_beli double,
	harga_jual double,
	stok_barang int(11)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

insert into tblBarang values ('121','Kenko',4000,5000,240);
insert into tblBarang values ('123','Sinar Dunia',1200,1450,200);
insert into tblBarang values ('212','Pilot',1200,1350,200);

create table tblSuplier (
	id_suplier int(11)PRIMARY KEY AUTO_INCREMENT,
	nama_suplier varchar(100),
	alamat varchar(100),
	telepon varchar(15)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

Insert into tblSuplier values (NULL,'CV.Majumundur','Jatiluhur Barat I no 162','02491967637');


create table tblPenjualan (
	id_penjualan int(12)PRIMARY KEY,
	id_barang varchar(10),
	id_admin int (11),
	nama_barang varchar(20),
	jumlah_barang int(11),
	harga_jual double,
	tanggal date,
	total double,
	FOREIGN KEY (id_admin) REFERENCES tblAdmin (id_admin),
	FOREIGN KEY (id_barang) REFERENCES tblBarang (id_barang)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

insert into tblPenjualan values (1,'212',113,'Pilot',2,2700,'2019-05-19',5400);
insert into tblPenjualan values (2,'121',113,'Kenko',5,3500,'2019-05-19',17500);
insert into tblPenjualan values (3,'212',113,'Pilot',3,4050,'2019-05-19',12150);
insert into tblPenjualan values (4,'212',113,'Pilot',3,4050,'2019-05-19',12150);
insert into tblPenjualan values (5,'212',113,'Pilot',3,4050,'2019-05-19',12150);
insert into tblPenjualan values (6,'212',113,'Pilot',2,2700,'2019-05-19',5400);
insert into tblPenjualan values (7,'212',113,'Pilot',3,4050,'2019-05-19',12150);
insert into tblPenjualan values (8,'121',113,'Kenko',3,2100,'2019-05-19',6300);
insert into tblPenjualan values (9,'121',113,'Kenko',2,1400,'2019-05-19',2800);
insert into tblPenjualan values (10,'121',113,'Kenko',5,3500,'2019-05-19',17500);


create table tblPemasukan_barang (
	id_pemasukanbarang int(11)PRIMARY KEY AUTO_INCREMENT,
	id_suplier int(11),
	id_barang varchar(10),
	jumlah_barang int(11),
	tanggal date,
	FOREIGN KEY (id_suplier) REFERENCES tblSuplier (id_suplier),
	FOREIGN KEY (id_barang) REFERENCES tblBarang (id_barang)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

insert into tblPemasukan_barang values (NULL,NULL,212,2,'2019-05-19');
