<?php 
include 'koneksi.php';

if(isset($_POST['Submit'])){
    $id_penjualan=$_POST['id_penjualan'];
    $tanggal=$_POST['tanggal'];
    $nama_barang=$_POST['nama_barang'];
    $harga_jual=$_POST['harga_jual'];
    $jumlah=$_POST['jumlah'];

    $query=mysqli_query($koneksi, "UPDATE tblPenjualan SET tanggal='$tanggal', nama_barang='$nama_barang', harga_jual='$harga_jual', jumlah='$jumlah' WHERE id_penjualan=$id_penjualan");

	if($query){
		header('location: baranglaku.php');
	}
	else{
        echo 'Gagal';
        
	}
}
?>

    