<?php 
include 'koneksi.php';
// echo($nama_barang);

$id_penjualan=$_POST['id_penjualan'];
$id_barang=$_POST['id_barang'];
$tanggal=$_POST['tanggal'];
$nama_barang=$_POST['nama_barang'];
$harga_jual=$_POST['harga_jual'];
$jumlah_barang=$_POST['jumlah_barang'];
// $total=$_POST['total'];

$koneksi=mysqli_connect("localhost","root","","dbtokoanakpintar");
$dt=mysqli_query($koneksi,"select * from tblPenjualan where nama_barang='$nama_barang'");
$data=mysqli_fetch_array($dt);
// $sisa=$data['jumlah']-$jumlah;
// mysql_query("update barang set jumlah='$sisa' where nama='$nama'");

// $modal=$data['modal'];
// $laba=$harga-$modal;
// $labaa=$laba*$jumlah;
$total=$harga_jual*$jumlah_barang;
mysqli_query($koneksi,"insert into tblPenjualan(id_penjualan,id_barang,tanggal,nama_barang,harga_jual,jumlah_barang,total) values('$id_penjualan','$id_barang','$tanggal','$nama_barang','$harga_jual','$jumlah_barang','$total')")or die(mysqli_error());

header("location:baranglaku.php");

?>