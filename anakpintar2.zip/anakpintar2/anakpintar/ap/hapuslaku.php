<?php 
include 'koneksi.php';
$id_barang=$_GET['id_barang'];
$jumlah_barang=$_GET['jumlah_barang'];
$nama_barang=$_GET['nama_barang'];

$a=mysqli_query($koneksi,"select jumlah from tblBarang where nama_barang='$nama_barang'");
$b=mysqli_fetch_array($a);
$kembalikan=$d['jumlah_barang']+$jumlah_barang;
$c=mysqli_query($koneksi,"update barang set jumlah_barang='$kembalikan' where nama_barang='$nama_barang'");
mysqli_query($koneksi,"delete from tblPenjualan where id_barang='$id_barang'");
header("location:baranglaku.php");

 ?>