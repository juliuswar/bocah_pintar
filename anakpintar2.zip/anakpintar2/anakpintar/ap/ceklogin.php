<?php
// mengaktifkan session php
session_start();

// menghubungkan dengan koneksi
include 'koneksi.php';

// menangkap data yang dikirim dari form
$username = $_POST['username'];
$password = $_POST['password'];

// menyeleksi data admin dengan username dan password yang sesuai
$data = mysqli_query($koneksi,"select * from tblAdmin where username='$username' and password='$password'");

// menghitung jumlah data yang ditemukan
while ($cek = mysqli_fetch_array($data)) {
		$_SESSION['username'] = $username;
		$_SESSION['status'] = "admin";
		header("location:admin.php");
}
  echo "<script>alert('Id atau Password salah');document.location='login.php'</script>";
?>
