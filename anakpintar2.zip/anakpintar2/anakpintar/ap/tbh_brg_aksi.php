<?php 
include 'koneksi.php';

// menangkap data yang di kirim dari form
$id_barang= $_POST['id_barang'];
$nama_barang= $_POST['nama_barang'];
$harga_beli= $_POST['harga_beli'];
$harga_jual= $_POST['harga_jual'];
$stok_barang= $_POST['stok_barang'];

// echo ($id_barang);
mysqli_query($koneksi,"insert into tblBarang values('$id_barang','$nama_barang','$harga_beli','$harga_jual','$stok_barang')");

header("location:barang.php?pesan=input");

?>