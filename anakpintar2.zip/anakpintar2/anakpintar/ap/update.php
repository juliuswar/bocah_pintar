<?php 
include 'koneksi.php';

if(isset($_POST['Submit'])){
    $id_barang=$_POST['id_barang'];
    $nama_barang=$_POST['nama_barang'];
    $harga_jual=$_POST['harga_jual'];
    $harga_beli=$_POST['harga_beli'];
    $stok_barang=$_POST['stok_barang'];

	$sql	= 'update tblBarang set nama_barang="'.$nama_barang.'", harga_jual="'.$harga_jual.'", harga_beli="'.$harga_beli.'", stok_barang="'.$stok_barang.'" where id_barang="'.$id_barang.'"';
	$query	= mysqli_query($koneksi,$sql);
	
	if($query){
		header('location: barang.php');
	}
	else{
        echo 'Gagal';
        
	}
}
?>

    