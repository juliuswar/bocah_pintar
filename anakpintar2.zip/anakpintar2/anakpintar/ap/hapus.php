<?php 
include 'koneksi.php';

$id_barang=$_GET['id'];
mysqli_query($koneksi,"delete from tblBarang where id_barang='$id_barang'");

header("location:barang.php");

?>